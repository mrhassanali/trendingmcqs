const usersController = require("./users.controller");
const postsController = require("./post.controller");
const categoryController = require("./category.controller");

module.exports={
    usersController,
    postsController,
    categoryController
}