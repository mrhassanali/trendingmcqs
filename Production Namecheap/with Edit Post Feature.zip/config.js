const siteName = "TrendingMCQs.com";
const description = "TrendingMcqs.com is Provide you the Latest Important MCQs of School,university,PPSC, job related,General Knowledge MCQs, and Communication Skills MCQs.";
const sitekeywords = ["trendingMcqs.com,university,PPSC, job related,General Knowledge MCQs, and Communication Skills MCQs."];
const footerDescription = " TrendingMcqs.com is Provide you the Latest Important MCQs of School,university,PPSC, job related,General Knowledge MCQs, and Communication Skills MCQs.";
export { siteName, description, sitekeywords,footerDescription };
