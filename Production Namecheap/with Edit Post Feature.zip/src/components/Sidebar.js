import { useEffect, useState } from "react";
import Image from 'next/image'
import Link from 'next/link'
import NextLink from "next/link";
import moment from "moment/moment";

export default function Sidebar() {
const[category,setcategory] = useState([]);
const[post,setPost] = useState([]);

useEffect(() => {

  fetch(`${process.env.NEXT_PUBLIC_BASE_URL}/api/category`, {
    method: "GET",
  })
    .then((response) => response.json())
    .then((data) => {
      setcategory(data);
    }).
    catch((error) => console.log(error));

      fetch(`${process.env.NEXT_PUBLIC_BASE_URL}/api/home-posts`, {
      method: "GET",
    })
      .then((response) => response.json())
      .then((data) => {
        setPost(data);
      }).catch((error) => console.log(error));

}, []);


  return (
<div className="position-sticky" style={{top: "2rem"}}>
<h3 className="pb-4 mb-4 fst-italic border-bottom">Popular Post</h3>
<div className="list-group">
{
  post.slice(0,4).map((element,index)=>{
    return(
      <NextLink href={`/post/${element.slug}`} key={index}>
      <div className="list-group-item list-group-item-action d-flex gap-3 py-3" aria-current="true">
      {
        element.image?<Image src={`${process.env.NEXT_PUBLIC_BASE_URL}/image/${element.image}`} 
        width="32" height="25"  
        alt={element.title}
        layout="fixed" className="rounded-circle flex-shrink-0"/>:""
      }
      <div className="d-flex gap-2 w-100 justify-content-between" style={{cursor:"pointer"}}>
        <div>
          <h6 className="mb-0">{element.title}</h6>
          {/* <p className="mb-0 opacity-75">{element.description.slice(0,45)}</p> */}
        </div>
        <small className="opacity-50 text-nowrap">{element.published? moment(element.published).fromNow():moment(element.updated).fromNow()}</small>
      </div>
      </div>
      
    </NextLink>
    )
  })
}

  </div>


    <div className="p-4">
      <h4 className="fst-italic">Category</h4>
      {
        category.slice(0,5).map((element,index)=>{
          // const{category_name,category_slug} = element;
         return(
          <Link href={`/category/${element.category_slug}`} key={index}>
          <button type="button" className="btn btn-outline-primary m-1">{element.category_name}</button>
        </Link>
         )
        })
      }
    </div>

  </div>
  )
}
