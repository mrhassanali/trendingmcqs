import Image from 'next/image' 
import Sidebar from '../components/Sidebar'
import HomePage from './HomePage'
import NextLink from 'next/link';
import moment from 'moment';
import { useEffect } from 'react';

export async function getServerSideProps() {
  const response = await fetch(`${process.env.NEXT_PUBLIC_BASE_URL}/api/home-posts`);
  const postdata = await response.json();

  return {
    props: {postdata}, // will be passed to the page component as props
  }
}

export default function Home({postdata}) {

return (
<>
  <div className="container mt-3">
  <div className="row mb-2">
        {
          postdata.slice(0,2).map((element,index)=>{
            const{title,description,slug,published,updated} = element;

          // const date = moment(published).format('YYYY-MM-DD');
          const publishedDate = moment(published).format('DD-MM-YYYY');
          const updatedDate = updated==null?null:moment(updated).format('DD-MM-YYYY');



            return(
              <div className="col-md-6" key={index}>
                <div className="row g-0 border rounded overflow-hidden flex-md-row mb-4 shadow-sm h-md-250 position-relative">
                  <div className="col p-4 d-flex flex-column position-static">
                  <NextLink href={`/category/${element.category.category_slug}`}>
                    <strong className={`d-inline-block mb-2 ${index==0?'text-primary':'text-success'}`}>{element.category.category_name.toUpperCase()}</strong>
                  </NextLink>
                    {/* <h3 className="mb-0 fw-bold">{title.slice(0,18)}</h3> */}
                    <h3 className="mb-0 fw-bold">{title.slice(0,30)}</h3>
                    <div className="mb-1 text-muted">{updated==null?publishedDate:updatedDate}</div>
                    <p className="card-text mb-auto">{description.slice(0,81)}</p>
            
                    <div className="d-grid gap-2 d-md-flex justify-content-md-end">
                      <NextLink href={`/post/${slug}`}>
                        <button className="btn btn-primary me-md-2" type="button">Read More</button>
                      </NextLink>
                    </div>
                  </div>
                </div>
              </div>
            )
          })
        }
    </div>

      <div className="row g-5">
        <div className="col-md-8">
          <h3 className="pb-4 mb-4 fst-italic border-bottom">Posts</h3>
            {
              postdata.map((element,index)=>{
                return <HomePage key={index} element={element}/>
              })
            }
        </div>
        <aside className="col-md-4"><Sidebar/></aside>
      </div>
</div>
</>
  )
}
