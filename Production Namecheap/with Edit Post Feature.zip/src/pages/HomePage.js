import Link from "next/link";
import Image from 'next/image'
import { useEffect } from "react";
import NextLink from "next/link";
import moment from "moment/moment";

export default function HomePage({element}) {
  useEffect(() => {
    const cards = document.querySelectorAll(".homepage");
    const observer = new IntersectionObserver((entries) => {
      entries.forEach((entry) => {
        const intersecting = entry.isIntersecting;
        entry.target.classList.toggle("show", intersecting);
        if (intersecting) observer.unobserve(entry.target);
      });
    }, { threshold: 0.6 });
    cards.forEach((card) => {
      observer.observe(card);
    });
  }, []);

  useEffect(() => {
    if (!element) {
      // Handle the case when element is undefined
      return;
    }
  }, [element]);

  if (!element) {
    // Handle the case when element is undefined
    return <div>Loading...</div>;
  }
  const {
    title,
    slug,
    published,
    updated,
    // description,
    image,
    category,
    author,
  } = element;


  const publishedDate = moment(published).format('DD-MM-YYYY');
  const updatedDate = updated==null?null:moment(updated).format('DD-MM-YYYY');


  return (
    <>
    <div className="card mb-3 homepage" style={{maxWidth: "740px",border:"none"}}>
      <div className="row g-0">
        <div className="col-md-4">
          {
            !(image == null)?<Image src={`${process.env.NEXT_PUBLIC_BASE_URL}/image/${image}`}
            width={250}
            height={190}
            layout="responsive"
            alt={`${title}`}
             priority
            />:<div style={{backgroundColor:"#f4f4f4",height:"100%",display:"flex",alignItems:"center",justifyContent:"center"}}>
              <span style={{fontFamily:"verdana",fontSize:"20px"}}>No Image</span>
            </div>
          }
        </div>
        <div className="col-md-8">
          <div className="card-body">

          <NextLink href={`/category/${category.category_slug}`}>
                <strong className="d-inline-block mb-2 text-success fw-bold">{category.category_name.toUpperCase()}</strong>
              </NextLink>

            <h5 className="card-title fw-bold fs-3" style={{fontFamily: "Roboto, sans-serif"}}>{title.slice(0,100)}</h5>

            <div className="d-flex flex-row mb-3">
              <Image 
                src={`${process.env.NEXT_PUBLIC_BASE_URL}/image/${author.image}`} 
                alt="..." 
                width={30}
                height={30}
                className="float-start rounded"
              />
              &nbsp;
              <h6 className="lh-base">{author.name}</h6>
            </div>
            <NextLink href={`/post/${slug}`}>
              <button type="button" className="btn btn-primary float-end m-3">Read More</button>
            </NextLink>
            <p className="card-text">
              <small  className="text-body-secondary">
                {updated==null?publishedDate:updatedDate}
              </small>
            </p>
          </div>
        </div>
      </div>
    </div>
    <hr/>
    </>
  )
}
