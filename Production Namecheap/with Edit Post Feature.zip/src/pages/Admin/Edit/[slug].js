import { useRouter } from "next/router";
import { useState, useEffect } from "react";

import { AppContext } from "../../../context/AppContext";
import { useContext } from "react";
import { getSession } from "next-auth/react";

import { toast } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";

export default function Slug({ category }) {
  const { user, authenticated } = useContext(AppContext);
  const router = useRouter();
  // console.log(router.query);

  const [InputImage, setInputImage] = useState(null);
  const [keywordcount, setkeywordcount] = useState(0);
  const [descriptioncount, setdescriptioncount] = useState(0);

  const [Input, setInput] = useState({
    id: "",
    title: "",
    slug: "",
    keyword: "",
    description: "",
    category_id: "",
    content: "",
    image: "",
    authorID: "",
    status: "",
    published: "",
    updated: "",
  });

  useEffect(() => {
    fetch(
      `${process.env.NEXT_PUBLIC_BASE_URL}/api/posts/${router.query.slug}`,
      {
        method: "GET",
        headers: {
          "Content-Type": "application/json",
        },
      }
    )
      .then((res) => res.json())
      .then((data) => {
        // setInput(data);
        setInput({
          id: data.id,
          title: data.title,
          slug: data.slug,
          keyword: data.keyword,
          description: data.description,
          category_id: data.category_id,
          content: data.content,
          image: data.image,
          authorID: data.authorID,
          status: data.status,
          published: data.published,
          updated: data.updated,
        });
        setInputImage(data.image);
        let myImage = `${process.env.NEXT_PUBLIC_BASE_URL}/image/${data.image}`;
        // Set the Image
        let createImg = document.createElement("img");
        createImg.setAttribute("alt", "preview Image");
        createImg.setAttribute("src", myImage);
        createImg.setAttribute(
          "style",
          "width:300px; height:300px,background-repeat:no-repeat;"
        );
        document.getElementById("PreviewImage").appendChild(createImg);
      });
  }, [router.query.slug]);

  useEffect(() => {
    document.title = "Edit Post";

    let UploadImage = document.getElementById("UploadImage");
    let previewImage = document.getElementById("PreviewImage");

    UploadImage.addEventListener(
      "change",
      function (event) {
        //check file is upload or not
        if (event.target.files.length == 0) {
          return;
        } else {
          var url = URL.createObjectURL(event.target.files[0]);
          if (document.getElementById("PreviewImage").hasChildNodes()) {
            document
              .getElementById("PreviewImage")
              .removeChild(document.getElementById("PreviewImage").firstChild);

            let createImg = document.createElement("img");
            createImg.setAttribute("alt", "preview Image");
            createImg.setAttribute("src", url);
            createImg.setAttribute(
              "style",
              "width:300px; height:300px,background-repeat:no-repeat;"
            );
            document.getElementById("PreviewImage").appendChild(createImg);
          } else {
            let createImg = document.createElement("img");
            createImg.setAttribute("alt", "preview Image");
            createImg.setAttribute("src", url);
            createImg.setAttribute(
              "style",
              "width:300px; height:300px,background-repeat:no-repeat;"
            );
            document.getElementById("PreviewImage").appendChild(createImg);
          }
        }
      }
    );
  }, [InputImage]);

  useEffect(() => {
    const textareas = document.querySelectorAll(".letter-counter");

    textareas.forEach((textarea) => {
      const charCount = textarea.nextElementSibling; // get the p element next to textarea
      textarea.addEventListener("input", () => {
        const length = textarea.value.length;
        charCount.textContent = length;
        if (length > 160) {
          charCount.style.color = "red"; // set color to red if length is greater than 160
        } else {
          charCount.style.color = "green"; // set color back to initial if length is less than or equal to 160
        }
      });
    });
  }, [Input.description,Input.keyword]);

  var fontStyle = {
    fontFamily: "sans-serif",
    fontStyle: "italic",
  };

  const InputFunc = (event) => {
    const { name, value } = event.target;
    setInput((preVal) => {
      return {
        ...preVal,
        [name]: value,
      };
    });
  };

  function handleButtonClick(event) {
    const clickedButtonValue = event.target.value;
    setInput((preVal) => {
      return {
        ...preVal,
        status: event.target.value,
      };
    });
    Input.status = clickedButtonValue;
    Input.image = InputImage;
    // console.log(Input);

    const formData = new FormData();
    formData.append("id", Input.id);
    formData.append("title", Input.title);
    formData.append("keyword", Input.keyword);
    formData.append("description", Input.description);
    formData.append("slug", Input.slug.trim().toLowerCase());
    formData.append("status", Input.status);
    formData.append("content", document.getElementById("postContent").value);
    formData.append("image", InputImage);
    formData.append("category_id", Input.category_id);
    // formData.append('authorID', 1);
    formData.append("authorID", Input.authorID);
    formData.append("published", Input.published);
    formData.append("updated", Input.updated);

    let token = window.localStorage.getItem("token");
    fetch(`${process.env.NEXT_PUBLIC_BASE_URL}/api/posts`, {
      method: "put",
      body: formData,
      headers: {
        authorization: token,
      },
    })
      .then((response) => response.json())
      .then((data) => {
        console.log(data);
        if (data.success) {
          toast.success("Post Add Successfully", {
            position: "top-right",
            autoClose: 3000,
            hideProgressBar: false,
            closeOnClick: true,
            pauseOnHover: true,
            draggable: true,
            progress: undefined,
            theme: "light",
          });
        } else {
          toast.error("Something Went Wrong", {
            position: "top-right",
            autoClose: 3000,
            hideProgressBar: false,
            closeOnClick: true,
            pauseOnHover: true,
            draggable: true,
            progress: undefined,
            theme: "light",
          });
        }
      })
      .catch((error) => console.log(error));
  }

  if (!Input) return <div>Loading...</div>;

  return (
    <>
      <div className="container mt-5">
        {Input ? (
          <form className="needs-validation">
            <div className="row g-5">
              <div className="col-md-7 col-lg-8">
                <div className="row g-3">
                  <div className="mb-3">
                    <label
                      htmlFor="title"
                      className="form-label fs-3 fw-bold"
                      style={fontStyle}
                    >
                      Post Title
                    </label>
                    <input
                      type="text"
                      className="form-control fs-4"
                      id="title"
                      name="title"
                      placeholder="Post Title"
                      onChange={InputFunc}
                      value={Input.title || ""}
                    />
                  </div>

                  <div className="d-flex justify-content-between">
                    <h3 className="fw-bold" style={fontStyle}>
                      Post Content
                    </h3>
                  </div>

                  {/* Content is Placed Here */}
                  <div id="content">
                    <div className="form-floating">
                      <textarea
                        className="form-control fs-4 border border-primary"
                        placeholder="Start Writing Post"
                        id="postContent"
                        name="postContent"
                        style={{ height: "600px", fontFamily: "consolas" }}
                        onChange={InputFunc}
                        value={Input.content || ""}
                      ></textarea>
                      <label htmlFor="postContent">Start Writing Post</label>
                    </div>
                  </div>
                </div>
              </div>
              {/* Side */}
              <div className="col-md-5 col-lg-4 order-md-last">
                <ul className="list-group mb-4">
                  <li className="list-group-item">
                    <div className="d-flex justify-content-between align-items-center">
                      <h6 className="my-0 fs-4 fw-bold" style={fontStyle}>
                        Post
                      </h6>
                      <div className="d-grid gap-1 d-md-flex justify-content-md-end">
                        <input
                          type="button"
                          className="btn btn-secondary"
                          name="status"
                          value="Save"
                          onClick={handleButtonClick}
                        ></input>
                        <input
                          type="button"
                          className="btn btn-danger"
                          name="status"
                          value="Draft"
                          onClick={handleButtonClick}
                        ></input>
                        <input
                          type="button"
                          className="btn btn-success"
                          name="status"
                          value="Published"
                          onClick={handleButtonClick}
                        ></input>
                      </div>
                    </div>
                  </li>
                </ul>

                <h4 className="d-flex justify-content-between align-items-center mb-3">
                  <span className="text-primary">SEO</span>
                  {/* <span className="badge bg-primary rounded-pill">3</span> */}
                </h4>
                <ul className="list-group mb-4">
                  <li className="list-group-item">
                    <div className="d-flex justify-content-between align-items-center">
                      <h6 className="my-0">Status</h6>
                      <small
                        className={`d-inline-flex px-2 py-1 fw-semibold border rounded-2 ${
                          Input.status == "Published"
                            ? " text-success-emphasis bg-success-subtle border-success-subtle"
                            : " text-danger-emphasis bg-danger-subtle border-danger-subtle "
                        }`}
                      >
                        {Input.status}
                      </small>
                    </div>
                  </li>
                  <li className="list-group-item">
                    <div>
                      <h6 className="my-0">Meta Keyword</h6>
                      <textarea
                        className="form-control mt-2 letter-counter"
                        id="keywords"
                        name="keyword"
                        placeholder="Enter meta tag keywords"
                        onChange={(event) => {
                          InputFunc(event);
                          setkeywordcount(event.target.value.length);
                        }}
                        value={Input.keyword || ""}
                        rows={4}
                      ></textarea>
                      <p style={{ float: "right" }}>{keywordcount}</p>
                    </div>
                  </li>
                  <li className="list-group-item">
                    <div>
                      <h6 className="my-0">Meta Description</h6>
                      <textarea
                        className="form-control mt-2 letter-counter"
                        id="description"
                        name="description"
                        placeholder="Enter meta tag keywords"
                        onChange={(e) => {
                          InputFunc(e);
                          setdescriptioncount(e.target.value.length);
                        }}
                        value={Input.description || ""}
                        rows={4}
                      ></textarea>
                      <p style={{ float: "right" }}>{descriptioncount}</p>
                    </div>
                  </li>
                  <li className="list-group-item">
                    <div>
                      <h6 className="my-0">Post Slug</h6>
                      <input
                        type="text"
                        className="form-control fs-7 mt-2"
                        id="slug"
                        name="slug"
                        placeholder="post-slug"
                        onChange={InputFunc}
                        value={Input.slug || ""}
                      />
                    </div>
                  </li>
                  <li className="list-group-item">
                    <div>
                      <h6 className="my-0">Select Category</h6>
                      <select
                        className="form-select mt-2"
                        //  defaultValue={Input.category_id || "DEFAULT"}
                        onChange={InputFunc}
                        value={Input.category_id || ""}
                        name="category"
                        aria-label="Default select example"
                      >
                        <option value="DEFAULT" disabled>
                          Select Category
                        </option>
                        {category.map((currValue, index) => {
                          return (
                            <option
                              key={index}
                              value={`${currValue.category_id}`}
                            >
                              {currValue.category_name}
                            </option>
                          );
                        })}
                      </select>
                    </div>
                  </li>
                  <li className="list-group-item">
                    <div>
                      <h6 className="my-0">Author</h6>
                      <select
                        className="form-select mt-2"
                        defaultValue={Input.authorID}
                        name="authorID"
                        aria-label="Default select example"
                      >
                        <option value="DEFAULT" disabled>
                          SELECT Author
                        </option>
                        <option value="1">Hassan Ali</option>
                      </select>
                    </div>
                  </li>
                </ul>

                <div>
                  <h3>Featured Image</h3>
                  <div className="input-group mb-3">
                    <label htmlFor="UploadImage" className="input-group-text">
                      Upload
                    </label>
                    <input
                      type="file"
                      className="form-control"
                      name="image"
                      id="UploadImage"
                      accept="image"
                      onChange={(e) => {
                        setInputImage(e.target.files[0]);
                      }}
                    />
                  </div>

                  <ul className="list-group mb-4">
                    <li className="list-group-item">
                      <div id="PreviewImage">
                        {/* <Image id="PreviewImage" alt="Preview" className="img-fluid" /> */}
                      </div>
                    </li>
                  </ul>
                </div>
              </div>
            </div>
          </form>
        ) : (
          "Loading..."
        )}
      </div>
    </>
  );
}

export async function getServerSideProps({ req, res }) {
  const session = await getSession({ req });

  const response = await fetch(
    `${process.env.NEXT_PUBLIC_BASE_URL}/api/category`
  );
  const category = await response.json();

  if (!session) {
    return {
      redirect: {
        destination: "/",
        permanent: false,
      },
    };
  }

  return {
    props: { session, category },
  };
}
