/** @type {import('next').NextConfig} */
const nextConfig = {
  reactStrictMode: true,
  images: {
    domains: ['images.unsplash.com','api.brainlymcqs.com','localhost','getbootstrap.com'],
  }
}

module.exports = nextConfig
