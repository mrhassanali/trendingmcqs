import {toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';

const Contact = () => {  




    return (
        <>
        {/* <div className="container mt-3 fs-5">
            <p>If you have any query regrading Site, Advertisement and any other issue, please feel free 
                to contact at email <b>hassanalikhan417@gmail.com</b> or fill blow form.</p>
        </div> */}

        <div className="container mt-5 d-flex justify-content-center">
        <iframe src="https://docs.google.com/forms/d/e/1FAIpQLSeQlfSxPJvTM1LtqeINwhHH1H3NhQpvLtBiLh-DfdVqR7YCaQ/viewform?embedded=true" 
        width="640" 
        height="980" 
        frameBorder="0" marginHeight="0" marginWidth="0">Loading…</iframe>

    </div>
        </>      
    );
}

export default Contact;