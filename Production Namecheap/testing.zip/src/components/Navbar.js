import NextLink from "next/link";
import { useRouter } from "next/router";
import { useState, useEffect } from "react";
import { AppContext } from "../context/AppContext";
import { useContext, useTransition } from "react";
import { useSession, signIn, signOut } from "next-auth/react";
import "bootstrap/dist/css/bootstrap.css";

export default function Navbar() {
  const { user, authenticated, Logout } = useContext(AppContext);
  const router = useRouter();

  const [isLoading, setIsLoading] = useState(true);

  const { data: session, status } = useSession();

  return (
    <header>
      <nav
        className="navbar navbar-expand-lg bg-light text-white"
        style={{
          fontSize: "19px",
          fontFamily: "'Fira Sans', sans-serif",
          fontWeight: "500",
        }}
      >
        <div className="container">
          <NextLink href="/">
            <a className="navbar-brand fw-bold">TrendingMCQs</a>
          </NextLink>
          <button
            className="navbar-toggler"
            type="button"
            data-bs-toggle="collapse"
            data-bs-target="#navbarSupportedContent"
            aria-controls="navbarSupportedContent"
            aria-expanded="false"
            aria-label="Toggle navigation"
          >
            <span className="navbar-toggler-icon"></span>
          </button>
          <div className="collapse navbar-collapse" id="navbarSupportedContent">
            <ul className="navbar-nav me-auto mb-2 mb-lg-0">
              <li className="nav-item">
                <NextLink href="/page/about">
                  <a className="nav-link">About</a>
                </NextLink>
              </li>
              <li className="nav-item">
                <NextLink href="/page/contact">
                  <a className="nav-link">Contact</a>
                </NextLink>
              </li>

              <li className="nav-item">
                <NextLink href="/page/privacy">
                  <a className="nav-link">Privacy Policy</a>
                </NextLink>
              </li>

              {
(status == 'authenticated')?(
  <li className="nav-item dropdown">
  <a className="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
    Post
  </a>
  <ul className="dropdown-menu">
    <li><NextLink href="/Admin/Post"> 
    <a className="dropdown-item" >Posts</a></NextLink>
    </li>
    <li><NextLink  href="/Admin/Category"> 
         <a className="dropdown-item">Category</a>
    </NextLink></li>
    <li><NextLink href="/Admin/AddPost"> 
     <a className="dropdown-item" >Add New Post</a>
    </NextLink></li>
  </ul>
</li>
):null
}

            </ul>
            <form className="d-flex" role="search">
              <input
                className="form-control me-2"
                type="search"
                placeholder="Search"
                name="search"
                aria-label="Search"
              />
              <button className="btn btn-outline-success" type="submit">
                Search
              </button>
            </form>
            <div className="d-flex">

{
(status == 'authenticated')? (<button type="button" className="btn btn-primary ms-2" onClick={()=>{
 window.localStorage.removeItem("token");
 router.push("https://www.trendingmcqs.com/");
 Logout();
}}>Logout</button>
):
("")     
}

</div>           
          </div>
        </div>
      </nav>
    </header>
  );
}
