"use strict";
(() => {
var exports = {};
exports.id = 823;
exports.ids = [823];
exports.modules = {

/***/ 7274:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ Category),
  "getServerSideProps": () => (/* binding */ getServerSideProps)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
;// CONCATENATED MODULE: ./src/components/Modal.js


function Modal({ isOpen , onClose , children , dataTarget , title , modalSize  }) {
    return /*#__PURE__*/ jsx_runtime_.jsx("div", {
        className: `modal fade fs-5 ${modalSize ? modalSize : "modal-lg"}`,
        id: dataTarget,
        tabIndex: "-1",
        "aria-labelledby": "exampleModalLabel",
        "aria-hidden": "true",
        children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
            className: "modal-dialog",
            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "modal-content",
                children: [
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: "modal-header",
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("h1", {
                                className: "modal-title fs-5",
                                id: "addnewcategory",
                                children: title
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("button", {
                                type: "button",
                                className: "btn-close",
                                "data-bs-dismiss": "modal",
                                "aria-label": "Close"
                            })
                        ]
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "modal-body",
                        children: children
                    })
                ]
            })
        })
    });
};

// EXTERNAL MODULE: external "next-auth/react"
var react_ = __webpack_require__(1649);
;// CONCATENATED MODULE: ./src/pages/Admin/Category.js




function Category({ categoryData  }) {
    const { 0: category , 1: setcategory  } = (0,external_react_.useState)(categoryData);
    const { 0: editcategory , 1: seteditcategory  } = (0,external_react_.useState)([]);
    // input Event
    const inputEvent = (event)=>{
        const { name , value  } = event.target;
        seteditcategory((preValue)=>{
            return {
                // preValue Return the obj that match to name and value
                ...preValue,
                [name]: value
            };
        });
    };
    const setCategoryState = (element)=>{
        seteditcategory(element);
    };
    //Handle Edit Category Submit Form
    const edithandleSubmit = (e)=>{
        e.preventDefault();
        const formData = new FormData();
        const data = new FormData(e.target);
        formData.append("categoryID", data.get("category_id"));
        formData.append("categoryName", data.get("category_name"));
        formData.append("categorySlug", data.get("category_slug"));
        let dt = {
            categoryID: editcategory.category_id,
            categoryName: data.get("category_name"),
            categorySlug: data.get("category_slug")
        };
        console.log(dt);
        fetch(`${"https://api.brainlymcqs.com"}/api/category/${dt.categoryID}`, {
            method: "PUT",
            body: JSON.stringify(dt),
            headers: {
                "Content-Type": "application/json; charset=UTF-8",
                "authorization": window.localStorage.getItem("token")
            },
            mode: "cors"
        }).then((response)=>response.json()).then((data)=>{
            console.log(data);
            const updatedCategories = category.map((category)=>category.category_id === dt.categoryID ? editcategory : category);
            setcategory(updatedCategories);
        }).catch((error)=>console.error("Error:", error));
    };
    // Edit Category Function
    function editCategoryFunc() {
        return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("form", {
            onSubmit: edithandleSubmit,
            children: [
                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                    className: "card p-3 shadow-sm p-3 mb-5 bg-body-tertiary rounded",
                    children: [
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            className: "input-group mb-3",
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                    className: "input-group-text",
                                    id: "editcategoryTitleText",
                                    children: "Title"
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("input", {
                                    type: "text",
                                    className: "form-control",
                                    name: "category_name",
                                    id: "category_name",
                                    placeholder: "Enter category Title",
                                    value: editcategory.category_name,
                                    onChange: inputEvent,
                                    "aria-label": "category",
                                    "aria-describedby": "basic-addon1"
                                })
                            ]
                        }),
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            className: "mb-3",
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx("label", {
                                    htmlFor: "basic-url",
                                    className: "form-label",
                                    children: "Slug"
                                }),
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                    className: "input-group",
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                            className: "input-group-text",
                                            id: "basic-addon3",
                                            children: "hassan-ali"
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("input", {
                                            type: "text",
                                            className: "form-control",
                                            id: "category_slug",
                                            name: "category_slug",
                                            value: editcategory.category_slug,
                                            onChange: inputEvent
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                    className: "form-text",
                                    id: "basic-addon4",
                                    children: "Example help text goes outside the input group."
                                })
                            ]
                        })
                    ]
                }),
                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                    className: "modal-footer",
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx("button", {
                            type: "button",
                            className: "btn btn-secondary",
                            "data-bs-dismiss": "modal",
                            children: "Close"
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("button", {
                            type: "submit",
                            className: "btn btn-primary",
                            children: "Update"
                        })
                    ]
                })
            ]
        });
    }
    function deleteCategoryFunc(deletecategory) {
        fetch(`${"https://api.brainlymcqs.com"}/api/category/${deletecategory}`, {
            method: "DELETE",
            headers: {
                "Content-Type": "application/json; charset=UTF-8",
                "authorization": window.localStorage.getItem("token")
            }
        }).then((response)=>response.json()).then((data)=>{
            console.log(data);
            // remove category id data and filter then return
            const newCategories = category.filter((category)=>category.category_id !== deletecategory);
            setcategory(newCategories);
        }).catch((error)=>console.error("Error:", error));
    }
    const handleSubmit = (e)=>{
        e.preventDefault();
        const formData = new FormData();
        const data = new FormData(e.target);
        formData.append("categoryName", data.get("categoryTitle"));
        formData.append("categorySlug", data.get("categorySlug"));
        let dt = {
            categoryName: data.get("categoryTitle"),
            categorySlug: data.get("categorySlug")
        };
        console.log(dt);
        fetch(`${"https://api.brainlymcqs.com"}/api/category`, {
            method: "POST",
            body: JSON.stringify(dt),
            headers: {
                "Content-Type": "application/json; charset=UTF-8",
                "authorization": window.localStorage.getItem("token")
            }
        }).then((response)=>response.json()).then((data)=>{
            console.log(data);
        // setcategory([...category, data]);
        }).catch((error)=>console.error("Error:", error));
        e.target.reset();
    };
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: "container mt-4",
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: "d-grid gap-2 d-md-flex justify-content-md-end",
                children: /*#__PURE__*/ jsx_runtime_.jsx("button", {
                    className: "btn btn-primary",
                    type: "button",
                    "data-bs-toggle": "modal",
                    "data-bs-target": "#addNewCategoryModal",
                    children: "Add Category"
                })
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("table", {
                className: "table fs-5 mt-3",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("thead", {
                        className: "bg-success text-white",
                        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("tr", {
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx("th", {
                                    scope: "col",
                                    children: "id"
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("th", {
                                    scope: "col",
                                    children: "Name"
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("th", {
                                    scope: "col",
                                    children: "Slug"
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("th", {
                                    scope: "col",
                                    style: {
                                        width: "1rem"
                                    },
                                    children: "Action"
                                })
                            ]
                        })
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("tbody", {
                        children: category.map((element, index)=>{
                            const { category_id , category_name , category_slug  } = element;
                            return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("tr", {
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("th", {
                                        children: category_id
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("td", {
                                        children: category_name
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("td", {
                                        children: category_slug
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("td", {
                                        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                            className: "d-grid gap-2 d-md-flex justify-content-md-end",
                                            children: [
                                                /*#__PURE__*/ jsx_runtime_.jsx("button", {
                                                    className: "btn btn-primary",
                                                    type: "button",
                                                    "data-bs-toggle": "modal",
                                                    "data-bs-target": "#editCategoryModal",
                                                    onClick: ()=>setCategoryState(element),
                                                    children: "Edit"
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx("button", {
                                                    className: "btn btn-danger",
                                                    type: "button",
                                                    onClick: ()=>deleteCategoryFunc(element.category_id),
                                                    children: "Delete"
                                                })
                                            ]
                                        })
                                    })
                                ]
                            }, index);
                        })
                    })
                ]
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(Modal, {
                dataTarget: "addNewCategoryModal",
                title: "Add New Category",
                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("form", {
                    onSubmit: handleSubmit,
                    children: [
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            className: "card p-3 shadow-sm p-3 mb-5 bg-body-tertiary rounded",
                            children: [
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                    className: "input-group mb-3",
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                            className: "input-group-text",
                                            id: "categoryTitleText",
                                            children: "Title"
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("input", {
                                            type: "text",
                                            className: "form-control",
                                            name: "categoryTitle",
                                            id: "categoryTitle",
                                            placeholder: "Enter category Title",
                                            "aria-label": "category",
                                            "aria-describedby": "basic-addon1"
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                    className: "mb-3",
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx("label", {
                                            htmlFor: "basic-url",
                                            className: "form-label",
                                            children: "Slug"
                                        }),
                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                            className: "input-group",
                                            children: [
                                                /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                    className: "input-group-text",
                                                    id: "basic-addon3",
                                                    children: "hassan-ali"
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx("input", {
                                                    type: "text",
                                                    className: "form-control",
                                                    id: "categorySlugs",
                                                    name: "categorySlug"
                                                })
                                            ]
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                            className: "form-text",
                                            id: "basic-addon4",
                                            children: "Example help text goes outside the input group."
                                        })
                                    ]
                                })
                            ]
                        }),
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            className: "modal-footer",
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx("button", {
                                    type: "button",
                                    className: "btn btn-secondary",
                                    "data-bs-dismiss": "modal",
                                    children: "Close"
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("button", {
                                    type: "submit",
                                    className: "btn btn-primary",
                                    children: "Add Category"
                                })
                            ]
                        })
                    ]
                })
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(Modal, {
                dataTarget: "editCategoryModal",
                title: "Update Category",
                children: editcategory && editCategoryFunc()
            })
        ]
    });
};
async function getServerSideProps({ req , res  }) {
    const session = await (0,react_.getSession)({
        req
    });
    let response = await fetch(`${"https://api.brainlymcqs.com"}/api/category`);
    let categoryData = await response.json();
    // if (!session) {
    //   res.setHeader('location', '/login');
    //   res.statusCode = 302;
    //   res.end();
    // }
    if (!session) {
        return {
            redirect: {
                destination: "/",
                permanent: false
            }
        };
    }
    return {
        props: {
            session,
            categoryData
        }
    };
}


/***/ }),

/***/ 1649:
/***/ ((module) => {

module.exports = require("next-auth/react");

/***/ }),

/***/ 6689:
/***/ ((module) => {

module.exports = require("react");

/***/ }),

/***/ 997:
/***/ ((module) => {

module.exports = require("react/jsx-runtime");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = (__webpack_exec__(7274));
module.exports = __webpack_exports__;

})();