"use strict";
(() => {
var exports = {};
exports.id = 748;
exports.ids = [748];
exports.modules = {

/***/ 1341:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "authOptions": () => (/* binding */ authOptions),
  "default": () => (/* binding */ _nextauth_)
});

;// CONCATENATED MODULE: external "next-auth"
const external_next_auth_namespaceObject = require("next-auth");
var external_next_auth_default = /*#__PURE__*/__webpack_require__.n(external_next_auth_namespaceObject);
;// CONCATENATED MODULE: external "next-auth/providers/credentials"
const credentials_namespaceObject = require("next-auth/providers/credentials");
var credentials_default = /*#__PURE__*/__webpack_require__.n(credentials_namespaceObject);
;// CONCATENATED MODULE: external "jsonwebtoken"
const external_jsonwebtoken_namespaceObject = require("jsonwebtoken");
var external_jsonwebtoken_default = /*#__PURE__*/__webpack_require__.n(external_jsonwebtoken_namespaceObject);
;// CONCATENATED MODULE: ./src/pages/api/auth/[...nextauth].js


 //for verify the token
const authOptions = {
    session: {
        strategy: "jwt"
    },
    providers: [
        credentials_default()({
            // name: 'Credentials',
            async authorize (credentials, req) {
                // const { user } = useContext(AppContext);
                // const router = useRouter();
                const { token , status  } = credentials;
                const decodedToken = external_jsonwebtoken_default().verify(token, process.env.SECRET_KEY);
                // if(!decodedToken.success){
                //   return null;
                // }
                if (decodedToken) {
                    return {
                        redirect: {
                            destination: "/BSF1905804",
                            permanent: false
                        }
                    };
                }
                const user = {
                    id: 1,
                    name: decodedToken.userName,
                    email: decodedToken.email
                };
                if (decodedToken.success) {
                    return user;
                } else {
                    return null;
                }
            }
        }), 
    ],
    secret: process.env.SECRET_KEY
};
/* harmony default export */ const _nextauth_ = (external_next_auth_default()(authOptions));


/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../../webpack-api-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = (__webpack_exec__(1341));
module.exports = __webpack_exports__;

})();